"""
Analysis and evaluation scripts.
"""
